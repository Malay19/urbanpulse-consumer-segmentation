"""
Test suite for Multimodal Consumer Segmentation Project
"""